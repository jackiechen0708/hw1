#ifndef ADD_H
#define ADD_H

int calculator(char *src);
void add_token(char start[100], int tok, int len);

#endif
