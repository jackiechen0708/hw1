#include "gtest/gtest.h"
#include "calculator.h"

char found_token[100];
int found_pos;

void add_token(char start[100], int tok, int len){
	found_token[found_pos++]=start[0];
}
class MyFirstTest : public ::testing::Test{
};

TEST_F(MyFirstTest,test11){
	char *txt="f00=(0x33)+13+/*a^123*72-128*/%>=<===";
	found_pos=0;
	int num=calculator(txt);
	found_token[found_pos]=0;
	EXPECT_EQ(num,12);
}
int main(int argc, char **argv){
	::testing::InitGoogleTest(&argc,argv);
	return RUN_ALL_TESTS();
}
