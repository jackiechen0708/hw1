#!/bin/bash
grep -c "<Author>" $1