#include "gtest/gtest.h"
#include "tree.h"

const char *tree[100];
const char *tree2[100];
int found_node;
int found_nodey;

void found_nodes(struct node*n){
	tree[found_node++]=n->txt;
}
void found_nodex(struct node*n){
	tree2[found_nodey++]=n->txt;
}


class MyFirstTest : public :: testing::Test{
};

TEST_F(MyFirstTest, test11){
	struct node*F=add_child(0, "F", 1, 2);
	struct node*B=add_child(F, "B", 1, 2);
	struct node*G=add_child(F, "G", 1, 2);
	struct node*A=add_child(B, "A", 1, 2);
	struct node*D=add_sibling(A, "D", 1, 2);
	struct node*C=add_child(D, "C", 1, 2);
	struct node*E=add_child(D, "E", 1, 2);
	struct node*I=add_child(G, "I", 1, 2);
	struct node*H=add_child(I, "H", 1, 2);
	(void)H;
	struct node*X=add_child(F, "X", 1, 2);
	struct node*Y=add_child(F, "Y", 1, 2);
	del_sub_tree(G);
	del_sub_tree(X);
	struct node*Z=add_child(Y, "Z", 1, 2);


	traverse_depth_first(found_nodes, F);
	tree[found_node]=0;	
	EXPECT_STREQ(tree[0], "F");
	EXPECT_STREQ(tree[1], "B");
	EXPECT_STREQ(tree[2], "A");
	EXPECT_STREQ(tree[3], "D");
	EXPECT_STREQ(tree[4], "C");
	EXPECT_STREQ(tree[5], "E");
	EXPECT_STREQ(tree[6], "Y");
	EXPECT_STREQ(tree[7], "Z");
	free(F);
	free(B);
	free(A);
	free(D);
	free(C);
	free(E);
	free(Y);
	free(Z);
}

TEST_F(MyFirstTest, test12){
        struct node*F=add_child(0, "F", 1, 2);
        struct node*B=add_child(F, "B", 1, 2);
        struct node*G=add_child(F, "G", 1, 2);
        struct node*A=add_child(B, "A", 1, 2);
        struct node*D=add_sibling(A, "D", 1, 2);
        struct node*C=add_child(D, "C", 1, 2);
        struct node*E=add_child(D, "E", 1, 2);
        struct node*I=add_child(G, "I", 1, 2);
        struct node*H=add_child(I, "H", 1, 2);

        traverse_breadth_first(found_nodex, F);
        tree2[found_nodey]=0;
        EXPECT_STREQ(tree2[0], "F");
        EXPECT_STREQ(tree2[1], "B");
        EXPECT_STREQ(tree2[2], "G");
        EXPECT_STREQ(tree2[3], "A");
        EXPECT_STREQ(tree2[4], "D");
        EXPECT_STREQ(tree2[5], "I");
        EXPECT_STREQ(tree2[6], "C");
	EXPECT_STREQ(tree2[7], "E");
	EXPECT_STREQ(tree2[8], "H");

	free(F);
	free(B);
	free(G);
	free(A);
	free(D);
	free(I);
	free(C);
	free(E);
	free(H);
}

int main(int argc, char **argv){
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
