#ifndef TREE_H
#define TREE_H

struct node{
	const char *txt;
	int len;
	int tok;
	struct node *children[100];
	struct node *parent;
	int childparent;
	int numc;
};

struct node* add_child(struct node *parent, const char *txt, int len, int tok);

struct node* add_child2(struct node *parent, struct node *child);

struct node* add_sibling(struct node *ptr, const char *txt, int len, int tok);

void del_sub_tree(struct node *tree);

void traverse_depth_first(void(*fun)(struct node*), struct node* root);

void traverse_breadth_first(void(*fun)(struct node*), struct node* root);

#endif
